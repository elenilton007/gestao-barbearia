# 🚀 O que falta para vender como SaaS

Análise do estado atual do projeto e do que é necessário para oferecê-lo
como serviço por assinatura para barbearias. Itens ordenados por prioridade.

## Estado atual

Hoje o sistema já **separa os dados por barbearia** (cada usuário só vê a
própria), rodando em SQLite local com o servidor de desenvolvimento do
Flask. Já tem
`SECRET_KEY` por variável de ambiente, debug desligado por padrão e
proteção CSRF nos formulários (Flask-WTF), e login com os papéis *dono*
e *barbeiro* (o barbeiro vê só os próprios atendimentos e comissões).
Tem cadastro de clientes, registro de atendimentos, comissões e relatórios
básicos. O dono cadastra, edita e desativa barbeiros, serviços e usuários
pelas telas, e rodar `python database.py` **apaga todos os dados**
(o schema começa com `DROP TABLE`).

## 🔴 Bloqueadores (sem isso não dá para cobrar de ninguém)

1. **Multi-tenancy** — cada barbearia precisa ver só os próprios dados.
   - ~~Criar tabela `barbearias` (tenant) e coluna `barbearia_id` em
     `clientes`, `barbeiros`, `servicos` e `atendimentos`.~~ Feito (também
     em `usuarios`).
   - ~~Filtrar **todas** as queries de `models.py` e `reports.py` pelo tenant
     da sessão.~~ Feito: a barbearia vem do usuário logado, e atendimento
     com cliente, barbeiro ou serviço de outra barbearia é recusado.
   - ~~Telas para a barbearia nova cadastrar os próprios barbeiros e
     serviços.~~ Feito (menus *Barbeiros* e *Serviços*, só para o dono).
   - ~~Cadastro de barbearia pela web~~ Feito (`/cadastro`, com termos de
     uso, limite contra robôs e primeiros passos na agenda). Falta período
     de teste e cobrança.
2. **Autenticação e permissões**
   - ~~Tabela `usuarios` com senha em hash (`werkzeug.security`), papéis
     *dono* e *barbeiro* (barbeiro vê só as próprias comissões).~~ Feito.
   - ~~Tela para o usuário (dono ou barbeiro) trocar a própria senha.~~ Feito (encerra as
     sessões abertas em outros aparelhos).
   - ~~Tela para o dono gerenciar usuários.~~ Feito (menu *Usuários*:
     cadastrar, mudar papel, trocar senha, desativar).
   - Papel *recepção* e recuperação de senha por e-mail.
3. **Segurança web**
   - ~~`SECRET_KEY` via variável de ambiente e proteção CSRF nos
     formulários (Flask-WTF).~~ Feito.
   - ~~Remover `debug=True` em produção.~~ Feito: o debug só liga com
     `FLASK_DEBUG=1`.
   - Validar entradas: hoje `valor_cobrado` aceita qualquer texto, IDs não
     são checados e o SQLite está com chaves estrangeiras desligadas
     (`PRAGMA foreign_keys = ON` não é executado).
   - ~~Rate limit no login.~~ Feito: 5 erros seguidos bloqueiam o
     usuário por 15 minutos. ~~Expiração da sessão.~~ Feito: 30 minutos
     sem uso.
   - ~~HTTPS e cookie `Secure`.~~ Feito no Render: HTTPS automático e
     `COOKIE_SEGURO=1` no `render.yaml`.
4. **Banco de produção e migrações**
   - ~~Migrar para PostgreSQL~~ Feito: com `DATABASE_URL` o sistema usa o
     PostgreSQL; sem ela, o SQLite continua para desenvolvimento local.
   - ~~Separar o schema dos dados de exemplo~~ Feito (`dados_exemplo.sql`).
     Falta usar migrações versionadas (Alembic) em vez das funções de
     atualização em `database.py`.
   - Guardar dinheiro como `NUMERIC`/centavos inteiros, não `REAL`.
     Por ora os valores são arredondados em centavos ao gravar e a
     comissão de cada atendimento é arredondada antes de somar, o que
     fecha as contas no centavo; a troca de tipo fica para as migrações.
   - Backups automáticos diários com teste de restauração.
5. **Cobrança da assinatura** — ~~integração com o Asaas: teste grátis,
   fatura mensal (Pix, boleto ou cartão), liberação e bloqueio automáticos
   pelo webhook~~ Feito (falta ligar no Render e emitir nota fiscal).
   Antes: integração com gateway brasileiro
   (Stripe, Asaas, Pagar.me, Mercado Pago, Iugu): planos, período de teste,
   cobrança recorrente por cartão/Pix/boleto, bloqueio por inadimplência,
   emissão de nota fiscal de serviço.
6. **Conformidade legal (LGPD)** — telefone e nome de clientes são dados
   pessoais: termos de uso, política de privacidade, contrato de
   processamento de dados com a barbearia, exportação e exclusão de dados
   do titular, registro de acessos.

## 🟠 Funcionalidades que o mercado espera

Concorrentes (Trinks, AppBarber, Booksy, Avec etc.) já oferecem:

- **Agenda / agendamento online** — o recurso mais importante.
  ~~Agenda por barbeiro, unidades, horário de funcionamento (com almoço),
  bloqueios, "sem preferência" (pega o barbeiro livre menos ocupado),
  comanda com vários serviços e concluir/faltou/cancelar lançando na
  gestão.~~ Feito (menus *Agenda* e *Unidades*). ~~**Link público** para o
  cliente marcar sozinho (`/b/<endereço>`), com cancelamento pelo link,
  arquivo de calendário, QR code e limites contra abuso~~ Feito (menu
  *Link de agendamento*). Falta remarcar pelo link, horário próprio por
  barbeiro e visão semanal.
- **Lembretes por WhatsApp/SMS** (confirmação e redução de faltas).
- **CRUD completo** — ~~editar/excluir clientes, ficha com histórico,
  busca e WhatsApp padronizado sem repetição~~ Feito. Falta editar e
  estornar atendimento.
- **Comissão congelada no atendimento** — hoje o relatório usa o percentual
  *atual* do barbeiro, então mudar a comissão na tela muda também a dos
  atendimentos antigos. Gravar o percentual em cada atendimento.
- ~~**Preenchimento automático do valor** a partir do preço do serviço.~~ Feito.
- **Filtro por período** nos relatórios (hoje somam *tudo* desde sempre) e
  fechamento de comissão por período, com marcação de "pago".
- **Caixa**: abertura/fechamento, despesas, sangrias, taxas de cartão.
- Venda de **produtos** e controle de estoque; **pacotes/planos de
  assinatura** do cliente da barbearia (ex.: "clube do corte").
- ~~Busca e histórico por cliente~~ Feito. Falta paginação.
- ~~Interface responsiva para celular~~ Feito (visual "Latão"). Falta PWA.
- Exportação para PDF/Excel.

## 🟡 Operação e infraestrutura

- ~~Servidor WSGI de produção (Gunicorn), PaaS (Render) e `Dockerfile`.~~
  Feito: veja *Publicar na internet* no README. Falta `docker-compose`
  para desenvolvimento.
- Configuração por variáveis de ambiente (12-factor) e arquivo `.env.example`.
- ~~CI (GitHub Actions) rodando os testes a cada push.~~ Feito, no SQLite
  e no PostgreSQL, e construindo a imagem Docker.
- Logs estruturados e monitoramento de erros (Sentry), uptime check.
- Onboarding: cadastro da barbearia → assistente inicial para criar
  serviços e barbeiros → importação de clientes por planilha.
- Painel administrativo seu (dono do SaaS): lista de assinantes, status de
  pagamento, métricas (MRR, churn).
- Domínio, landing page com preços, canal de suporte.

## Sugestão de ordem de execução

1. Migrações + PostgreSQL + `barbearia_id` em todas as tabelas.
2. Login, papéis, validação de entrada.
3. CRUD completo de barbeiros/serviços/clientes e filtros de período.
4. Agenda e agendamento online (principal argumento de venda).
5. Deploy (Docker + Gunicorn + HTTPS), backups, Sentry, CI.
6. Cobrança recorrente, LGPD/termos e lançamento com algumas barbearias
   piloto antes de abrir ao público.
